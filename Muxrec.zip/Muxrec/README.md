# Muxrec
Load an MP3/WAV, play it, talk over it (or pause and talk), export the whole thing as MP3 or WAV.

## Build on GitHub
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab -> **Build APK** (runs on every push, or press *Run workflow*).
3. When it finishes, download the **Muxrec-APK** artifact, unzip, install `app-debug.apk`.

The debug keystore is included, so every new build installs over the previous one without uninstalling.

## Use
- LOAD a track, press play. The mic starts with the play button.
- "Talk over it": mic is always live. "Pause to talk": mic is silenced while the track plays.
- Pick Phone / Bluetooth / External mic. Use headphones so the track doesn't leak into the mic.
- FINISH stops the mic (play again to continue the same project). EXPORT mixes it to MP3, WAV or MP4 (a photo from your gallery + the audio).
