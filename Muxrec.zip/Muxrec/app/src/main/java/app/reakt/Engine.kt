package app.reakt

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.media.ExifInterface
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.naman14.androidlame.LameBuilder
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

const val SR = 44100
/** Fade (in frames) applied at the edges of every music segment so pause/seek cuts don't click. */
const val FADE = 882

/** One stretch where the source was playing: wall = position on the project timeline, src = position in the track (frames). */
class Seg(val wall: Long, val src: Long, var len: Long = 0)

/** Streams decoded audio out as 44.1k stereo s16le while collecting waveform peaks. */
private class Sink(private val out: OutputStream) {
    var frames = 0L
    val peaks = ArrayList<Float>()
    private var t = 0.0
    private var pl = 0f
    private var pr = 0f
    private var pk = 0f
    private var pc = 0

    fun push(a: ShortArray, ch: Int, rate: Int) {
        val nf = a.size / ch
        if (nf == 0) return
        val step = rate.toDouble() / SR
        val bb = ByteBuffer.allocate((ceil(nf / step).toInt() + 4) * 4).order(ByteOrder.LITTLE_ENDIAN)
        val r1 = if (ch > 1) 1 else 0
        while (true) {
            val i0 = floor(t).toInt()
            if (i0 + 1 > nf - 1) break
            val f = (t - i0).toFloat()
            val l0 = if (i0 < 0) pl else a[i0 * ch].toFloat()
            val l1 = a[(i0 + 1) * ch].toFloat()
            val q0 = if (i0 < 0) pr else a[i0 * ch + r1].toFloat()
            val q1 = a[(i0 + 1) * ch + r1].toFloat()
            val l = l0 + (l1 - l0) * f
            val r = q0 + (q1 - q0) * f
            bb.putShort(l.toInt().coerceIn(-32768, 32767).toShort())
            bb.putShort(r.toInt().coerceIn(-32768, 32767).toShort())
            pk = max(pk, max(abs(l), abs(r)))
            pc++
            if (pc == 1024) { peaks.add(pk / 32768f); pk = 0f; pc = 0 }
            frames++
            t += step
        }
        t -= nf
        pl = a[(nf - 1) * ch].toFloat()
        pr = a[(nf - 1) * ch + r1].toFloat()
        out.write(bb.array(), 0, bb.position())
    }

    fun close() = out.close()
}

class Engine(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val origFile = File(ctx.cacheDir, "orig.pcm")
    private val micFile = File(ctx.cacheDir, "mic.pcm")

    // ---------- UI state ----------
    var trackName by mutableStateOf<String?>(null); private set
    var durationMs by mutableIntStateOf(0); private set
    var positionMs by mutableIntStateOf(0)
    var playing by mutableStateOf(false); private set
    var recording by mutableStateOf(false); private set
    var projectSec by mutableIntStateOf(0); private set
    var level by mutableFloatStateOf(0f); private set
    var history by mutableStateOf(listOf<Float>()); private set
    var peaks by mutableStateOf(FloatArray(0)); private set
    var busy by mutableStateOf<String?>(null); private set
    var exportPct by mutableStateOf<Float?>(null); private set
    var status by mutableStateOf("")
    var talkOver by mutableStateOf(true); private set
    var micKind by mutableIntStateOf(0); private set          // 0 phone, 1 bluetooth, 2 external
    var inputs by mutableStateOf(listOf<AudioDeviceInfo>()); private set
    var musicVol by mutableFloatStateOf(0.8f)
    var voiceVol by mutableFloatStateOf(1f)
    var headphones by mutableStateOf(true); private set
    @Volatile var coverBmp: Bitmap? = null; private set

    // ---------- internals ----------
    @Volatile private var micFrames = 0L
    @Volatile private var recRun = false
    @Volatile private var playFlag = false
    @Volatile private var talkFlag = true
    @Volatile private var rawLevel = 0f
    private var srcFrames = 0L
    private var player: MediaPlayer? = null
    private var rec: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var recThread: Thread? = null
    private val segs = ArrayList<Seg>()
    private var open: Seg? = null

    private val cb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(d: Array<out AudioDeviceInfo>?) { refreshDevices() }
        override fun onAudioDevicesRemoved(d: Array<out AudioDeviceInfo>?) { refreshDevices() }
    }

    init {
        am.registerAudioDeviceCallback(cb, main)
        refreshDevices()
        headphones = headphonesPlugged()
    }

    private fun headphonesPlugged(): Boolean = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
        when (it.type) {
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> true
            else -> Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
        }
    }

    /** Headphones ON = raw mic. OFF = echo canceller + noise suppressor (when the phone has them). */
    fun setHeadphones(b: Boolean) { headphones = b; applyFx() }

    private fun applyFx() {
        try { aec?.enabled = !headphones } catch (_: Throwable) {}
        try { ns?.enabled = !headphones } catch (_: Throwable) {}
    }

    val hasTrack get() = player != null
    val hasProject get() = micFrames > 0

    fun hasMic() = ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ---------- microphones ----------
    private fun kindOf(t: Int): Int = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> 0
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> 1
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> 2
        else -> if (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET) 1 else -1
    }

    fun deviceFor(kind: Int): AudioDeviceInfo? = inputs.firstOrNull { kindOf(it.type) == kind }

    fun refreshDevices() {
        inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        if (micKind != 0 && deviceFor(micKind) == null) pickMic(0)
    }

    fun pickMic(kind: Int) {
        micKind = kind
        val d = deviceFor(kind)
        try {
            if (kind == 1) {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                if (Build.VERSION.SDK_INT >= 31) {
                    am.availableCommunicationDevices.firstOrNull { it.id == d?.id }?.let { am.setCommunicationDevice(it) }
                } else {
                    am.startBluetoothSco()
                    am.isBluetoothScoOn = true
                }
            } else {
                am.mode = AudioManager.MODE_NORMAL
                if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
                else { am.stopBluetoothSco(); am.isBluetoothScoOn = false }
            }
        } catch (_: Throwable) {}
        try { rec?.setPreferredDevice(d) } catch (_: Throwable) {}
    }

    fun setTalkOver(b: Boolean) { talkOver = b; talkFlag = b }

    private fun startMic(): Boolean {
        if (recRun) return true
        if (!hasMic()) return false
        try {
            val min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val src = if (micKind == 1) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
            val ar = AudioRecord(src, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, SR))
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release(); status = "Microphone unavailable"; return false
            }
            deviceFor(micKind)?.let { ar.setPreferredDevice(it) }
            val os = FileOutputStream(micFile, true)
            ar.startRecording()
            rec = ar
            try { if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(ar.audioSessionId) } catch (_: Throwable) {}
            try { if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(ar.audioSessionId) } catch (_: Throwable) {}
            applyFx()
            recRun = true
            recording = true
            try { ctx.startForegroundService(Intent(ctx, ReaktService::class.java)) } catch (_: Throwable) {}
            recThread = thread(name = "reakt-mic") {
                val buf = ShortArray(1024)
                val bytes = ByteArray(2048)
                try {
                    while (recRun) {
                        val n = ar.read(buf, 0, buf.size)
                        if (n < 0) break
                        if (n == 0) continue
                        var pk = 0
                        val gateOpen = talkFlag || !playFlag
                        for (i in 0 until n) {
                            val v = buf[i].toInt()
                            pk = max(pk, abs(v))
                            val w = if (gateOpen) v else 0
                            bytes[2 * i] = w.toByte()
                            bytes[2 * i + 1] = (w shr 8).toByte()
                        }
                        os.write(bytes, 0, n * 2)
                        micFrames += n
                        rawLevel = pk / 32768f
                    }
                } finally {
                    try { os.close() } catch (_: Throwable) {}
                }
            }
            return true
        } catch (t: Throwable) {
            status = "Mic error: ${t.message}"
            return false
        }
    }

    private fun stopMic() {
        if (!recRun) return
        recRun = false
        try { recThread?.join(800) } catch (_: Throwable) {}
        try { rec?.stop() } catch (_: Throwable) {}
        try { aec?.release() } catch (_: Throwable) {}
        try { ns?.release() } catch (_: Throwable) {}
        aec = null; ns = null
        try { rec?.release() } catch (_: Throwable) {}
        rec = null
        recording = false
        try { ctx.stopService(Intent(ctx, ReaktService::class.java)) } catch (_: Throwable) {}
        rawLevel = 0f
    }

    // ---------- project timeline ----------
    private fun openSeg(srcMs: Int) {
        if (!recRun) return
        closeSeg()
        val s = Seg(micFrames, srcMs.toLong() * SR / 1000)
        segs.add(s)
        open = s
    }

    private fun closeSeg() {
        val s = open ?: return
        s.len = micFrames - s.wall
        if (s.len <= 0) segs.remove(s)
        open = null
    }

    private fun wipeProject() {
        open = null
        segs.clear()
        micFrames = 0
        micFile.delete()
        projectSec = 0
        history = emptyList()
    }

    // ---------- transport ----------
    fun startRec() { status = ""; startMic() }

    fun togglePlay() { if (playing) pause() else play() }

    fun play() {
        status = ""
        val mp = player ?: run { status = "Load an MP3 or WAV first"; return }
        if (exportPct != null) return
        if (!startMic()) {
            if (!hasMic()) status = "Microphone permission needed"
            return
        }
        val atEnd = durationMs > 0 && mp.currentPosition >= durationMs - 80
        if (atEnd) mp.seekTo(0)
        val srcMs = if (atEnd) 0 else mp.currentPosition
        mp.start()
        playFlag = true
        playing = true
        openSeg(srcMs)
    }

    fun pause() {
        try { player?.pause() } catch (_: Throwable) {}
        closeSeg()
        playFlag = false
        playing = false
    }

    fun seekTo(ms: Int) {
        val mp = player ?: return
        val c = ms.coerceIn(0, durationMs)
        val was = playing
        if (was) closeSeg()
        mp.seekTo(c)
        positionMs = c
        if (was) openSeg(c)
    }

    fun finish() {
        pause()
        stopMic()
        projectSec = (micFrames / SR).toInt()
    }

    fun discard() {
        if (exportPct != null) return
        pause(); stopMic(); wipeProject(); status = ""
    }

    private fun onEnded() {
        closeSeg()
        playFlag = false
        playing = false
        positionMs = durationMs
    }

    fun tick() {
        val mp = player
        if (mp != null && playing) {
            try { positionMs = mp.currentPosition } catch (_: Throwable) {}
        }
        projectSec = (micFrames / SR).toInt()
        level = if (recRun) rawLevel else 0f
        history = if (recRun) (history + level).takeLast(80) else if (history.isEmpty()) history else emptyList()
    }

    fun release() {
        pause(); stopMic()
        try { player?.release() } catch (_: Throwable) {}
        try { am.unregisterAudioDeviceCallback(cb) } catch (_: Throwable) {}
        try { am.mode = AudioManager.MODE_NORMAL } catch (_: Throwable) {}
    }

    // ---------- loading ----------
    private fun queryName(u: Uri): String {
        var n: String? = null
        try {
            ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) n = it.getString(0)
            }
        } catch (_: Throwable) {}
        return n ?: "Track"
    }

    fun loadTrack(uri: Uri) {
        pause(); stopMic(); wipeProject()
        try { player?.release() } catch (_: Throwable) {}
        player = null
        trackName = null; peaks = FloatArray(0); durationMs = 0; positionMs = 0
        busy = "Preparing track…"; status = ""
        val name = queryName(uri)
        thread(name = "reakt-decode") {
            try {
                val (pk, frames) = decode(uri)
                main.post {
                    try {
                        val mp = MediaPlayer()
                        mp.setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build()
                        )
                        mp.setDataSource(ctx, uri)
                        mp.prepare()
                        mp.setOnCompletionListener { onEnded() }
                        mp.setOnErrorListener { _, _, _ -> status = "Playback error"; true }
                        player = mp
                        srcFrames = frames
                        peaks = pk
                        durationMs = (frames * 1000 / SR).toInt()
                        trackName = name
                    } catch (t: Throwable) {
                        status = "Can't play that file"
                    }
                    busy = null
                }
            } catch (t: Throwable) {
                main.post { busy = null; status = "Couldn't read that file" }
            }
        }
    }

    private fun decode(uri: Uri): Pair<FloatArray, Long> {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                ex.selectTrack(i); fmt = f; break
            }
        }
        if (fmt == null) { ex.release(); throw IOException("no audio track") }
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val sink = Sink(BufferedOutputStream(FileOutputStream(origFile), 1 shl 16))
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        try {
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val n = ex.readSampleData(codec.getInputBuffer(ii)!!, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val arr = ShortArray(sb.remaining())
                    sb.get(arr)
                    sink.push(arr, ch, rate)
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
        } finally {
            try { codec.stop() } catch (_: Throwable) {}
            codec.release(); ex.release(); sink.close()
        }
        val raw = sink.peaks
        val bins = 160
        val out = FloatArray(bins)
        if (raw.isNotEmpty()) {
            for (i in raw.indices) {
                val b = min(bins - 1, (i.toLong() * bins / raw.size).toInt())
                out[b] = max(out[b], raw[i])
            }
            var mx = 0.05f
            for (v in out) mx = max(mx, v)
            for (i in out.indices) out[i] = (out[i] / mx).coerceIn(0.04f, 1f)
        }
        return Pair(out, sink.frames)
    }

    // ---------- cover photo (for MP4) ----------
    /** Decodes the picked photo and fits it on a black 16:9 / 9:16 / square canvas (even sizes for the encoder). */
    fun setCover(uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val orient = try {
                ctx.contentResolver.openInputStream(uri)!!.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            } catch (_: Throwable) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            }
            val ratio = bmp.width.toFloat() / bmp.height
            val cw: Int
            val ch: Int
            if (ratio > 1.2f) { cw = 1280; ch = 720 }
            else if (ratio < 0.83f) { cw = 720; ch = 1280 }
            else { cw = 1024; ch = 1024 }
            val out = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            c.drawColor(android.graphics.Color.BLACK)
            val sc = min(cw.toFloat() / bmp.width, ch.toFloat() / bmp.height)
            val dw = bmp.width * sc
            val dh = bmp.height * sc
            c.drawBitmap(bmp, null, RectF((cw - dw) / 2, (ch - dh) / 2, (cw + dw) / 2, (ch + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            coverBmp = out
            true
        } catch (t: Throwable) {
            false
        }
    }

    // ---------- export ----------
    /** kind: 0 = MP3, 1 = WAV, 2 = MP4 (needs a cover photo set with setCover). */
    fun export(kind: Int, dest: Uri) {
        if (exportPct != null || recRun || micFrames == 0L) return
        val cover = coverBmp
        if (kind == 2 && cover == null) { status = "Pick a photo for the MP4"; return }
        exportPct = 0f
        status = "Mixing…"
        val total = micFrames
        val segList = segs.toList()
        val mv = musicVol
        val vv = voiceVol
        thread(name = "reakt-export") {
            var ok = false
            var msg = ""
            try {
                if (kind == 2) {
                    val tmp = File(ctx.cacheDir, "out.mp4")
                    try {
                        mixToMp4(tmp, cover!!, total, segList, mv, vv)
                        ctx.contentResolver.openOutputStream(dest, "wt")!!.buffered(1 shl 16).use { out ->
                            FileInputStream(tmp).use { it.copyTo(out) }
                        }
                    } finally {
                        tmp.delete()
                    }
                } else {
                    ctx.contentResolver.openOutputStream(dest, "wt")!!.buffered(1 shl 16).use { out ->
                        mix(out, kind == 0, total, segList, mv, vv)
                    }
                }
                ok = true
            } catch (t: Throwable) {
                msg = if (kind == 0 && t is LinkageError) "MP3 encoder not available — export WAV instead"
                else "Export failed: ${t.message}"
                try { DocumentsContract.deleteDocument(ctx.contentResolver, dest) } catch (_: Throwable) {}
            }
            main.post { exportPct = null; status = if (ok) "Saved ✓" else msg }
        }
    }

    private fun clip(f: Float): Short = f.coerceIn(-32768f, 32767f).toInt().toShort()

    private fun wavHeader(dataBytes: Long): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt((36 + dataBytes).toInt())
        b.put("WAVE".toByteArray()); b.put("fmt ".toByteArray())
        b.putInt(16); b.putShort(1); b.putShort(2)
        b.putInt(SR); b.putInt(SR * 4); b.putShort(4); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataBytes.toInt())
        return b.array()
    }

    /** Mixes the project (voice + track segments) and hands every finished stereo chunk to [sink]. */
    private fun mixPcm(total: Long, segList: List<Seg>, mv: Float, vv: Float, sink: (ShortArray, ShortArray, Int, Long) -> Unit) {
        val chunk = 4096
        val micIn = BufferedInputStream(FileInputStream(micFile), 1 shl 16)
        val orig = RandomAccessFile(origFile, "r")
        val micBytes = ByteArray(chunk * 2)
        val srcBytes = ByteArray(chunk * 4)
        val mixL = FloatArray(chunk)
        val mixR = FloatArray(chunk)
        val oL = ShortArray(chunk)
        val oR = ShortArray(chunk)
        var t = 0L
        var si = 0
        var count = 0
        try {
            while (t < total) {
                val n = min(chunk.toLong(), total - t).toInt()
                var got = 0
                while (got < n * 2) {
                    val r = micIn.read(micBytes, got, n * 2 - got)
                    if (r < 0) break
                    got += r
                }
                java.util.Arrays.fill(micBytes, got, n * 2, 0.toByte())
                for (i in 0 until n) {
                    val m = ((micBytes[2 * i + 1].toInt() shl 8) or (micBytes[2 * i].toInt() and 0xFF)) * vv
                    mixL[i] = m
                    mixR[i] = m
                }
                while (si < segList.size && segList[si].wall + segList[si].len <= t) si++
                var k = si
                while (k < segList.size && segList[k].wall < t + n) {
                    val s = segList[k]
                    val a = max(t, s.wall)
                    val b = min(t + n, s.wall + s.len)
                    val sp = s.src + (a - s.wall)
                    val c = min(b - a, srcFrames - sp).toInt()
                    if (c > 0) {
                        orig.seek(sp * 4)
                        orig.readFully(srcBytes, 0, c * 4)
                        val off = (a - t).toInt()
                        val fromStart = a - s.wall
                        for (j in 0 until c) {
                            val l = (srcBytes[4 * j + 1].toInt() shl 8) or (srcBytes[4 * j].toInt() and 0xFF)
                            val r = (srcBytes[4 * j + 3].toInt() shl 8) or (srcBytes[4 * j + 2].toInt() and 0xFF)
                            val pos = fromStart + j
                            val g = min(1f, min(pos.toFloat() / FADE, (s.len - pos).toFloat() / FADE))
                            mixL[off + j] += l * mv * g
                            mixR[off + j] += r * mv * g
                        }
                    }
                    k++
                }
                for (i in 0 until n) { oL[i] = clip(mixL[i]); oR[i] = clip(mixR[i]) }
                sink(oL, oR, n, t)
                t += n
                count++
                if (count % 24 == 0) {
                    val p = t.toFloat() / total
                    main.post { exportPct = p }
                }
            }
        } finally {
            micIn.close()
            orig.close()
        }
    }

    private fun mix(out: OutputStream, mp3: Boolean, total: Long, segList: List<Seg>, mv: Float, vv: Float) {
        val chunk = 4096
        val lame = if (mp3) LameBuilder()
            .setInSampleRate(SR)
            .setOutChannels(2)
            .setOutBitrate(192)
            .setOutSampleRate(SR)
            .setQuality(3)
            .build() else null
        val mp3buf = ByteArray(chunk * 2 + 8192)
        val wavOut = ByteArray(chunk * 4)
        if (!mp3) out.write(wavHeader(total * 4))
        mixPcm(total, segList, mv, vv) { oL, oR, n, _ ->
            if (lame != null) {
                val nb = lame.encode(oL, oR, n, mp3buf)
                if (nb < 0) throw IOException("MP3 encode error $nb")
                out.write(mp3buf, 0, nb)
            } else {
                for (i in 0 until n) {
                    wavOut[4 * i] = oL[i].toByte()
                    wavOut[4 * i + 1] = (oL[i].toInt() shr 8).toByte()
                    wavOut[4 * i + 2] = oR[i].toByte()
                    wavOut[4 * i + 3] = (oR[i].toInt() shr 8).toByte()
                }
                out.write(wavOut, 0, n * 4)
            }
        }
        if (lame != null) {
            val fl = lame.flush(mp3buf)
            if (fl > 0) out.write(mp3buf, 0, fl)
            lame.close()
        }
    }

    private fun mixToMp4(tmp: File, cover: Bitmap, total: Long, segList: List<Seg>, mv: Float, vv: Float) {
        val w = Mp4Writer(tmp, cover, total)
        try {
            mixPcm(total, segList, mv, vv) { oL, oR, n, t -> w.audio(oL, oR, n, t) }
            w.finish()
        } catch (t: Throwable) {
            w.abort()
            throw t
        }
    }
}
