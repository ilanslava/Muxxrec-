package app.reakt

import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer

/** Encodes the mixed audio (AAC) plus one still photo (H.264, 2 fps) into an .mp4 file. */
class Mp4Writer(tmp: File, cover: Bitmap, totalFrames: Long) {
    private val w = cover.width
    private val h = cover.height
    private val fps = 2
    private val stepUs = 1_000_000L / fps
    private val totalUs = totalFrames * 1_000_000L / SR

    private val yArr = ByteArray(w * h)
    private val uArr = ByteArray((w / 2) * (h / 2))
    private val vArr = ByteArray((w / 2) * (h / 2))

    private val muxer = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val aenc: MediaCodec
    private lateinit var venc: MediaCodec
    private var aTrack = -1
    private var vTrack = -1
    private var started = false
    private var aDone = false
    private var vDone = false
    private var nextV = 0L
    private val pending = ArrayList<Pend>()
    private val info = MediaCodec.BufferInfo()
    private var pcm = ByteArray(0)

    private class Pend(val audio: Boolean, val data: ByteBuffer, val info: MediaCodec.BufferInfo)

    init {
        // photo -> I420 planes (BT.601, limited range), chroma averaged over 2x2
        val px = IntArray(w * h)
        cover.getPixels(px, 0, w, 0, 0, w, h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val p = px[y * w + x]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                yArr[y * w + x] = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(0, 255).toByte()
            }
        }
        for (y in 0 until h / 2) {
            for (x in 0 until w / 2) {
                var r = 0; var g = 0; var b = 0
                for (dy in 0..1) for (dx in 0..1) {
                    val p = px[(2 * y + dy) * w + 2 * x + dx]
                    r += (p shr 16) and 0xFF
                    g += (p shr 8) and 0xFF
                    b += p and 0xFF
                }
                r /= 4; g /= 4; b /= 4
                uArr[y * (w / 2) + x] = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255).toByte()
                vArr[y * (w / 2) + x] = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255).toByte()
            }
        }

        val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2)
        af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        af.setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
        af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        try {
            aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aenc.start()
            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            vf.setInteger(MediaFormat.KEY_BIT_RATE, 600_000)
            vf.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            venc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            venc.start()
        } catch (t: Throwable) {
            try { aenc.release() } catch (_: Throwable) {}
            try { muxer.release() } catch (_: Throwable) {}
            throw t
        }
    }

    /** One mixed chunk of n stereo frames starting at frame t of the project timeline. */
    fun audio(oL: ShortArray, oR: ShortArray, n: Int, t: Long) {
        val ptsUs = t * 1_000_000L / SR
        while (nextV * stepUs <= ptsUs && nextV * stepUs < totalUs) {
            val ts = nextV * stepUs
            nextV++
            feedVideo(ts)
        }
        if (pcm.size < n * 4) pcm = ByteArray(n * 4)
        for (i in 0 until n) {
            pcm[4 * i] = oL[i].toByte()
            pcm[4 * i + 1] = (oL[i].toInt() shr 8).toByte()
            pcm[4 * i + 2] = oR[i].toByte()
            pcm[4 * i + 3] = (oR[i].toInt() shr 8).toByte()
        }
        feedAudio(pcm, n * 4, t)
        drain(0)
    }

    fun finish() {
        while (nextV * stepUs < totalUs || nextV == 0L) {
            val ts = nextV * stepUs
            nextV++
            feedVideo(ts)
        }
        queueEos(aenc, totalUs)
        queueEos(venc, nextV * stepUs)
        var guard = 0
        while (!(aDone && vDone)) {
            drain(10_000)
            if (++guard > 3000) throw IOException("Encoder did not finish")
        }
        try { aenc.stop() } catch (_: Throwable) {}
        aenc.release()
        try { venc.stop() } catch (_: Throwable) {}
        venc.release()
        if (!started) throw IOException("No encoded data")
        muxer.stop()
        muxer.release()
    }

    fun abort() {
        try { aenc.release() } catch (_: Throwable) {}
        try { venc.release() } catch (_: Throwable) {}
        try { muxer.release() } catch (_: Throwable) {}
    }

    private fun feedAudio(bytes: ByteArray, len: Int, frameBase: Long) {
        var off = 0
        var tries = 0
        while (off < len) {
            val ii = aenc.dequeueInputBuffer(10_000)
            if (ii < 0) {
                drain(0)
                if (++tries > 500) throw IOException("Audio encoder stalled")
                continue
            }
            tries = 0
            val ib = aenc.getInputBuffer(ii)!!
            ib.clear()
            val c = minOf(len - off, ib.capacity()) and 3.inv()
            ib.put(bytes, off, c)
            val pts = (frameBase + off / 4) * 1_000_000L / SR
            aenc.queueInputBuffer(ii, 0, c, pts, 0)
            off += c
        }
    }

    private fun feedVideo(ptsUs: Long) {
        var tries = 0
        while (true) {
            val ii = venc.dequeueInputBuffer(10_000)
            if (ii < 0) {
                drain(0)
                if (++tries > 500) throw IOException("Video encoder stalled")
                continue
            }
            val img = venc.getInputImage(ii) ?: throw IOException("Video encoder has no image input")
            fill(img.planes[0], yArr, w, h)
            fill(img.planes[1], uArr, w / 2, h / 2)
            fill(img.planes[2], vArr, w / 2, h / 2)
            venc.queueInputBuffer(ii, 0, w * h * 3 / 2, ptsUs, 0)
            return
        }
    }

    private fun fill(p: Image.Plane, src: ByteArray, pw: Int, ph: Int) {
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        if (ps == 1) {
            for (r in 0 until ph) {
                buf.position(r * rs)
                buf.put(src, r * pw, pw)
            }
        } else {
            for (r in 0 until ph) {
                val base = r * rs
                val sb = r * pw
                for (c in 0 until pw) buf.put(base + c * ps, src[sb + c])
            }
        }
    }

    private fun queueEos(c: MediaCodec, ptsUs: Long) {
        var tries = 0
        while (true) {
            val ii = c.dequeueInputBuffer(10_000)
            if (ii >= 0) {
                c.queueInputBuffer(ii, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                return
            }
            drain(0)
            if (++tries > 500) throw IOException("Encoder stalled")
        }
    }

    private fun drain(timeoutUs: Long) {
        drainCodec(aenc, true, timeoutUs)
        drainCodec(venc, false, timeoutUs)
    }

    private fun drainCodec(c: MediaCodec, isAudio: Boolean, timeoutUs: Long) {
        while (true) {
            val oi = c.dequeueOutputBuffer(info, timeoutUs)
            if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) return
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val t = muxer.addTrack(c.outputFormat)
                if (isAudio) aTrack = t else vTrack = t
                if (aTrack >= 0 && vTrack >= 0 && !started) {
                    muxer.start()
                    started = true
                    for (p in pending) muxer.writeSampleData(if (p.audio) aTrack else vTrack, p.data, p.info)
                    pending.clear()
                }
                continue
            }
            if (oi < 0) continue
            val buf = c.getOutputBuffer(oi)!!
            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
            if (info.size > 0) {
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                if (started) {
                    muxer.writeSampleData(if (isAudio) aTrack else vTrack, buf, info)
                } else {
                    val copy = ByteBuffer.allocate(info.size)
                    copy.put(buf)
                    copy.flip()
                    val bi = MediaCodec.BufferInfo()
                    bi.set(0, info.size, info.presentationTimeUs, info.flags)
                    pending.add(Pend(isAudio, copy, bi))
                }
            }
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                if (isAudio) aDone = true else vDone = true
            }
            c.releaseOutputBuffer(oi, false)
        }
    }
}
