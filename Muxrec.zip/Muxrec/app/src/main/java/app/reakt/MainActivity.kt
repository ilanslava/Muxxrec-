package app.reakt

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.sqrt

// ---- palette: black, white ink, one blue for the source, one red for the voice ----
val Bg = Color(0xFF000000)
val Panel = Color(0xFF0D0F12)
val Edge = Color(0xFF3D434C)
val Ink = Color(0xFFFFFFFF)
val Dim = Color(0xFFB4BAC4)
val Off = Color(0xFF8A919C)
val Mute = Color(0xFF626B78)
val Blue = Color(0xFF4DA3FF)
val Red = Color(0xFFFF453A)
val Mono = FontFamily.Monospace

fun fmt(ms: Int): String {
    val s = max(ms, 0) / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

class MainActivity : ComponentActivity() {
    private lateinit var engine: Engine

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        engine.refreshDevices()
    }
    private val openAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) engine.loadTrack(u)
    }
    private val saveMp3 = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { u ->
        if (u != null) engine.export(0, u)
    }
    private val saveWav = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { u ->
        if (u != null) engine.export(1, u)
    }
    private val saveMp4 = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { u ->
        if (u != null) engine.export(2, u)
    }
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            if (engine.setCover(u)) {
                val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                saveMp4.launch("muxrec-$stamp.mp4")
            } else {
                engine.status = "Couldn't read that photo"
            }
        }
    }

    private fun askPerms() {
        val want = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) want.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) want.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = want.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) perms.launch(missing.toTypedArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = Engine(applicationContext)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        askPerms()
        setContent {
            ReaktTheme {
                Screen(
                    e = engine,
                    onLoad = { openAudio.launch(arrayOf("audio/*")) },
                    onPerm = { askPerms() },
                    onSave = { kind ->
                        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                        when (kind) {
                            0 -> saveMp3.launch("muxrec-$stamp.mp3")
                            1 -> saveWav.launch("muxrec-$stamp.wav")
                            else -> pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) engine.release()
    }
}

@Composable
fun ReaktTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, onPrimary = Color.Black,
            background = Bg, onBackground = Ink,
            surface = Panel, onSurface = Ink
        ),
        content = content
    )
}

@Composable
fun Screen(e: Engine, onLoad: () -> Unit, onPerm: () -> Unit, onSave: (Int) -> Unit) {
    LaunchedEffect(Unit) { while (true) { e.tick(); delay(50) } }
    var confirmLoad by remember { mutableStateOf(false) }
    var confirmDiscard by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = max(e.durationMs, 1)
    val progress = drag ?: (e.positionMs.toFloat() / dur)
    val muted = e.recording && e.playing && !e.talkOver

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("MUXREC", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                Spacer(Modifier.weight(1f))
                Text("PAUSE · SPEAK · EXPORT", color = Dim, fontSize = 10.sp, letterSpacing = 2.sp)
            }

            // ------------------------------- 01 SOURCE -------------------------------
            Win("01", "SOURCE", Blue, right = {
                Chip("LOAD", false, true, Blue) { if (e.hasProject) confirmLoad = true else onLoad() }
            }) {
                Text(
                    e.trackName ?: "No track loaded",
                    color = if (e.trackName == null) Dim else Ink,
                    fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Wave(e.peaks, progress, Modifier.fillMaxWidth().height(84.dp))
                Slider(
                    value = progress,
                    onValueChange = { drag = it },
                    onValueChangeFinished = { drag?.let { e.seekTo((it * dur).toInt()) }; drag = null },
                    colors = sliderColors()
                )
                Row(Modifier.fillMaxWidth()) {
                    Text(fmt((progress * dur).toInt()), color = Ink, fontFamily = Mono, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    Text(fmt(e.durationMs), color = Dim, fontFamily = Mono, fontSize = 13.sp)
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Skip("−10") { e.seekTo(e.positionMs - 10000) }
                    PlayButton(e.playing) {
                        if (e.hasTrack && !e.hasMic()) onPerm() else e.togglePlay()
                    }
                    Skip("+10") { e.seekTo(e.positionMs + 10000) }
                }
            }

            // ------------------------------- 02 VOICE -------------------------------
            Win("02", "VOICE", Red, right = {
                Text(
                    (if (e.recording) "● REC  " else "PROJECT  ") + fmt(e.projectSec * 1000),
                    color = if (e.recording) Red else Dim,
                    fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
            }) {
                Label("MICROPHONE")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Phone", e.micKind == 0, true, Red) { e.pickMic(0) }
                    val bt = e.deviceFor(1) != null
                    Chip("Bluetooth", e.micKind == 1, bt, Red) { e.pickMic(1) }
                    val ext = e.deviceFor(2) != null
                    Chip("External", e.micKind == 2, ext, Red) { e.pickMic(2) }
                }
                Label("HEADPHONES")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("On", e.headphones, true, Blue) { e.chooseHeadphones(true) }
                    Chip("Off", !e.headphones, true, Blue) { e.chooseHeadphones(false) }
                }
                Label("WHILE THE TRACK PLAYS")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Talk over it", e.talkOver, true, Blue) { e.chooseTalkOver(true) }
                    Chip("Pause to talk", !e.talkOver, true, Blue) { e.chooseTalkOver(false) }
                }
                Canvas(
                    Modifier.fillMaxWidth().height(56.dp)
                        .clip(RoundedCornerShape(10.dp)).background(Color(0xFF07080A))
                ) {
                    val n = 80
                    val w = size.width / n
                    val h = e.history
                    h.forEachIndexed { idx, v ->
                        val x = (n - h.size + idx) * w + w / 2
                        val bh = max(4f, sqrt(v) * size.height)
                        drawLine(
                            if (muted) Mute else Red,
                            Offset(x, size.height / 2 - bh / 2), Offset(x, size.height / 2 + bh / 2),
                            strokeWidth = w * 0.6f, cap = StrokeCap.Round
                        )
                    }
                }
                val line = when {
                    e.status.isNotEmpty() -> e.status
                    !e.recording && e.projectSec > 0 -> "Session paused — press play to continue, or export"
                    !e.recording -> "Press play on the track, or START to talk first"
                    muted -> "Mic muted while the track plays — pause to talk"
                    e.playing && !e.headphones && e.talkOver -> "No headphones: the mic may pick up the track (echo)"
                    e.playing -> "Talking over the track — mic is live"
                    else -> "Track paused — mic is live, speak"
                }
                Text(line, color = Ink, fontSize = 13.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (e.recording) Pill("■ FINISH", Ink, Modifier.weight(1f)) { e.finish() }
                    else Pill("● START", Red, Modifier.weight(1f)) { if (!e.hasMic()) onPerm() else e.startRec() }
                    if (!e.recording && e.projectSec > 0) {
                        Pill("EXPORT", Blue, Modifier.weight(1f)) { showExport = true }
                    }
                }
            }
        }

        e.busy?.let { msg ->
            Box(
                Modifier.fillMaxSize().background(Color(0xE6000000)).clickable(enabled = true, onClick = {}),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Blue)
                    Spacer(Modifier.height(14.dp))
                    Text(msg, color = Ink, fontSize = 15.sp)
                }
            }
        }
    }

    if (confirmLoad) Confirm(
        "Loading a new track discards the current project. Export it first if you want to keep it.",
        "DISCARD & LOAD", { confirmLoad = false; onLoad() }, { confirmLoad = false }
    )
    if (confirmDiscard) Confirm(
        "Delete everything recorded so far?",
        "DISCARD", { confirmDiscard = false; showExport = false; e.discard() }, { confirmDiscard = false }
    )

    if (showExport) {
        val exporting = e.exportPct != null
        AlertDialog(
            onDismissRequest = { if (!exporting) showExport = false },
            containerColor = Panel,
            confirmButton = {
                TextButton(onClick = { showExport = false }, enabled = !exporting) {
                    Text("CLOSE", color = if (exporting) Off else Ink, fontWeight = FontWeight.Bold)
                }
            },
            title = { Text("Export project", color = Ink, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Length ${fmt(e.projectSec * 1000)} · the track and your voice, exactly as you recorded them",
                        color = Dim, fontSize = 13.sp
                    )
                    Text("Track volume  ${(e.musicVol * 100).toInt()}%", color = Ink, fontSize = 13.sp)
                    Slider(value = e.musicVol, onValueChange = { e.musicVol = it }, valueRange = 0f..1f, colors = sliderColors())
                    Text("Voice volume  ${(e.voiceVol * 100).toInt()}%", color = Ink, fontSize = 13.sp)
                    Slider(value = e.voiceVol, onValueChange = { e.voiceVol = it }, valueRange = 0f..2f, colors = sliderColors())
                    val p = e.exportPct
                    if (p != null) {
                        LinearProgressIndicator(progress = { p }, color = Blue, trackColor = Edge, modifier = Modifier.fillMaxWidth())
                    }
                    if (e.status.isNotEmpty()) Text(e.status, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("MP3", Blue, Modifier.weight(1f)) { onSave(0) }
                        Pill("WAV", Blue, Modifier.weight(1f)) { onSave(1) }
                        Pill("MP4", Blue, Modifier.weight(1f)) { onSave(2) }
                    }
                    Text("MP4 = a photo from your gallery + the audio", color = Dim, fontSize = 11.sp)
                    TextButton(onClick = { confirmDiscard = true }, enabled = !exporting) {
                        Text("Discard project", color = if (exporting) Off else Red)
                    }
                }
            }
        )
    }
}

// ------------------------------- building blocks -------------------------------

@Composable
fun Win(
    index: String, title: String, accent: Color,
    right: @Composable () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Edge, shape).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(8.dp))
            Text("$index  $title", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.weight(1f))
            right()
        }
        content()
    }
}

@Composable
fun Label(t: String) = Text(t, color = Dim, fontSize = 10.sp, letterSpacing = 2.sp)

@Composable
fun Chip(text: String, selected: Boolean, enabled: Boolean, accent: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fg = when {
        selected -> Color.Black
        enabled -> Ink
        else -> Off
    }
    Box(
        Modifier.clip(shape)
            .background(if (selected) accent else Color.Transparent)
            .border(1.dp, if (selected) accent else Edge, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Text(text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Pill(text: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(50)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun Skip(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).border(1.dp, Edge, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PlayButton(playing: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(72.dp).clip(CircleShape).background(Ink).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(28.dp)) {
            if (playing) {
                drawRect(Color.Black, Offset(size.width * 0.10f, 0f), Size(size.width * 0.30f, size.height))
                drawRect(Color.Black, Offset(size.width * 0.60f, 0f), Size(size.width * 0.30f, size.height))
            } else {
                val p = Path().apply {
                    moveTo(size.width * 0.15f, 0f)
                    lineTo(size.width, size.height / 2)
                    lineTo(size.width * 0.15f, size.height)
                    close()
                }
                drawPath(p, Color.Black)
            }
        }
    }
}

@Composable
fun Wave(peaks: FloatArray, progress: Float, modifier: Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF07080A))) {
        val n = peaks.size
        if (n == 0) {
            drawLine(Edge, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), strokeWidth = 2f)
            return@Canvas
        }
        val w = size.width / n
        for (i in 0 until n) {
            val h = max(4f, peaks[i] * size.height * 0.92f)
            val x = i * w + w / 2
            drawLine(
                if ((i + 0.5f) / n <= progress) Blue else Mute,
                Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = w * 0.62f, cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun sliderColors() = SliderDefaults.colors(thumbColor = Ink, activeTrackColor = Blue, inactiveTrackColor = Edge)

@Composable
fun Confirm(text: String, yes: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        containerColor = Panel,
        text = { Text(text, color = Ink, fontSize = 15.sp) },
        confirmButton = { TextButton(onClick = onYes) { Text(yes, color = Red, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onNo) { Text("CANCEL", color = Ink) } }
    )
}
